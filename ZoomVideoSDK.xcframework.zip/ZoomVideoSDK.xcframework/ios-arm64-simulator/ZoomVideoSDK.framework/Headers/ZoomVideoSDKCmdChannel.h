/**
 * @file ZoomVideoSDKCmdChannel.h
 * @brief Interface for command channel operations allowing custom command data exchange between session participants.
 */

#import <Foundation/Foundation.h>

@class ZoomVideoSDKSubSessionUser;

/**
 * @class ZoomVideoSDKCmdChannel
 * @brief The command channel, allows users to send commands or data (such as plain text or a binary encoded into string) to other users in the same session. See [ZoomVideoSDK.h#getCmdChannel].
 */
@interface ZoomVideoSDKCmdChannel : NSObject
/**
 * @brief Sends custom commands or data to other users in the current session. This API is rate-limited; overly frequent calls return Errors_Call_Too_Frequently.
 * @param commandContent The custom commands or data, represented in string format.
 * @param user An instance of ZoomVideoSDKUser associated with the user who receives the command. If receiver is set to nil, the command is broadcast to all users.
 * @return If the function succeeds, it returns Errors_Success. Otherwise, this function returns an error.
 */
- (ZoomVideoSDKError)sendCommand:(NSString * _Nullable)commandContent receiveUser:(ZoomVideoSDKUser * _Nullable)user;

/**
 * @brief Sends a command to a subsession user. Supports cross-session delivery between the main
 *        session and subsessions (breakout rooms).
 * @param commandContent The custom command or data.
 * @param subSessionUser The target subsession user. Obtain it from ZoomVideoSDKSubSessionKit.getSubSessionUserList.
 * @return If the function succeeds, it returns Errors_Success. Otherwise, this function returns an error.
 */
- (ZoomVideoSDKError)sendCommandToSubSessionUser:(NSString * _Nullable)commandContent subSessionUser:(ZoomVideoSDKSubSessionUser * _Nullable)subSessionUser;

@end
